(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_next_dist_b93b88b6._.js",
  "static/chunks/src_5259758d._.js"
],
    source: "dynamic"
});
