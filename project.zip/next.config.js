/** @type {import('next').NextConfig} */
const nextConfig = {
  // اگر خواستی بعداً flagهای experimental بذاری:
  // experimental: { appDir: true },
};

module.exports = nextConfig;