import React from 'react'

function Footer() {
  return (
    <div className='w-full h-[5rem] bg-black flex justify-center items-center text-white mt-20'>Footer</div>
  )
}

export default Footer